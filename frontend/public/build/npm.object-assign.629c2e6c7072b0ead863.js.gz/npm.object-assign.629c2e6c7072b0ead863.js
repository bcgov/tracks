(window.webpackJsonp=window.webpackJsonp||[]).push([[11],{MgzW:function(r,t,e){"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/var n=Object.getOwnPropertySymbols,o=Object.prototype.hasOwnProperty,c=Object.prototype.propertyIsEnumerable;function a(r){if(null==r)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(r)}r.exports=function(){try{if(!Object.assign)return!1;var r=new String("abc");if(r[5]="de","5"===Object.getOwnPropertyNames(r)[0])return!1;for(var t={},e=0;e<10;e++)t["_"+String.fromCharCode(e)]=e;if("0123456789"!==Object.getOwnPropertyNames(t).map((function(r){return t[r]})).join(""))return!1;var n={};return"abcdefghijklmnopqrst".split("").forEach((function(r){n[r]=r})),"abcdefghijklmnopqrst"===Object.keys(Object.assign({},n)).join("")}catch(r){return!1}}()?Object.assign:function(r,t){for(var e,i,s=a(r),p=1;p<arguments.length;p++){for(var b in e=Object(arguments[p]))o.call(e,b)&&(s[b]=e[b]);if(n){i=n(e);for(var f=0;f<i.length;f++)c.call(e,i[f])&&(s[i[f]]=e[i[f]])}}return s}}}]);
//# sourceMappingURL=npm.object-assign.629c2e6c7072b0ead863.js.map